package com.cheaky.imagesexample

import android.R.attr
import android.graphics.Bitmap
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.gifdecoder.StandardGifDecoder
import com.bumptech.glide.load.resource.gif.GifDrawable
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.reflect.Field


class MainActivity : AppCompatActivity() {

    private lateinit var animationDrawable: AnimationDrawable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        imageView.apply {
            setBackgroundResource(R.drawable.test)
            animationDrawable = background as AnimationDrawable
        }
        button.setOnClickListener {
            animationDrawable.stop()
            animationDrawable.selectDrawable(0)
            when(editText.text.toString()){
                "1"->{
                    animationDrawable.addFrame(resources.getDrawable(R.drawable.android), 1000)
                    animationDrawable.start()
                }
                "2"->{
                    animationDrawable.addFrame(resources.getDrawable(R.drawable.octavelogo), 1000)
                    animationDrawable.start()
                }
                "3"->{
                    animationDrawable.addFrame(resources.getDrawable(R.drawable.rlogo), 1000)
                    animationDrawable.start()
                }
                "4"->{
                    animationDrawable.addFrame(resources.getDrawable(R.drawable.pythonlogo), 1000)
                    animationDrawable.start()
                }
                else -> {
                    animationDrawable.addFrame(resources.getDrawable(R.drawable.yo), 1000)
                    animationDrawable.start()
                }
            }
        }



    }

    override fun onStart() {
        super.onStart()

        /*rocketAnimation.addFrame(resources.getDrawable(R.drawable.test), 1000)
        rocketAnimation.start()*/

    }

}

